1. Please make sure the root file of the java file is EnhancedVersion
2. Please make sure the package of the java file is EnhancedVersion
3. Please make sure enter name.png, mainMenu.png, question.png, result.png and summary.png appear on the 
   left hand side of the project explorer which they are loaded into the EnhancedVersion package